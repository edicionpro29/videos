# editor-reels — editor de reels de marcas para Claude

Skill de Claude que edita los reels de una jornada de contenido: le pasás el Drive de la jornada
(carpetas "Reel N", "Crudos", voces en off y guion) y la web de la marca, y te devuelve los reels
editados con voz limpia, subtítulos palabra por palabra, gráficos con la identidad de la marca,
la tienda real en un celular, música propia y control de calidad cuadro por cuadro.

## Instalar
Seguí `1 - LEEME.txt` (viene con la compra): pegás un texto en Claude Code y Claude instala todo.
Claude encuentra los pasos técnicos en `references/instalacion.md`.

## Primer uso
Decile a Claude algo como: "Te paso el Drive de la jornada de <marca> y su web <url>. Editá los reels
según el guion, dejalos en el Escritorio en una carpeta <MARCA>, y con Crudos armá 3 extras."

## Qué hay adentro
- `SKILL.md`: las reglas de oro y el mapa de la skill.
- `references/`: instalación, flujo paso a paso, voz, gráficos, música, control de calidad, fichas de
  marca y otros formatos.
- `scripts/` y `assets/`: lo que usa Claude para editar, la plantilla de gráficos y ejemplos.

Versión 1.0 · octubre 2026.
