# Instalación (una sola vez por compu) — instrucciones para Claude

Esto lo lee Claude, no el usuario. **Regla de oro 12:** al usuario no le nombres ninguna de estas
herramientas. Decile "voy a instalar lo que necesita la skill (programas de edición, de audio y de
transcripción)" y pedile permiso antes de cada instalación, en esos términos.

## 1. Detectar el sistema
- Mac: `uname` → Darwin. Windows: PowerShell / `%USERPROFILE%`.
- Carpeta de skills: Mac `~/.claude/skills/`, Windows `%USERPROFILE%\.claude\skills\`.

## 2. Instalar la skill
- El comprador descarga `editor-reels.zip` (de la página de compra) y lo descomprime: queda una carpeta
  `tu-editor-de-reels/` con `editor-reels/` adentro. Buscala en Descargas y en el Escritorio.
- Copiá `editor-reels/` a la carpeta de skills, de modo que quede `.../.claude/skills/editor-reels/SKILL.md`.
  Si ya existe, preguntá antes de reemplazarla.

## 3. Programas que usa (revisá qué falta y pedí permiso antes de cada uno)
| Qué | Mac (Homebrew) | Windows (winget) | Cómo verificar |
|---|---|---|---|
| ffmpeg + ffprobe | `brew install ffmpeg` | `winget install Gyan.FFmpeg` (abrir consola nueva) | `ffmpeg -version` |
| Python 3.11+ | `brew install python@3.12` | `winget install Python.Python.3.12` | `python3 --version` / `python --version` |
| Node 18+ | `brew install node` | `winget install OpenJS.NodeJS.LTS` | `node -v` |
- En Mac, si no hay Homebrew, pedile al usuario que lo instale desde brew.sh (necesita su contraseña).
- Librerías de Python (en Mac, mejor en un entorno virtual: `python3 -m venv ~/.venvs/reels` y usar ese
  `python`): `pip install faster-whisper numpy scipy pillow pillow-heif noisereduce playwright`.
- Proyecto de Remotion 4.x en un disco con lugar (no en una carpeta sincronizada con OneDrive/iCloud),
  por ejemplo `~/Proyectos/remotion-editor` o `C:\Proyectos\remotion-editor`:
  `npx create-video@latest` (plantilla en blanco; si el asistente es interactivo y no podés contestarle,
  pedile al usuario que lo corra) y adentro, con LA MISMA versión que remotion (`npx remotion versions`):
  `npm i @remotion/google-fonts@<versión> @remotion/renderer@<versión>` y `npx remotion browser ensure`.
- Si el navegador de capturas no aparece: `python -m playwright install chromium`.

## 4. Verificar
- `python -c "import faster_whisper, noisereduce, pillow_heif, playwright, scipy, PIL; print('ok')"`
- `python <skills>/editor-reels/scripts/musica.py --estilos` (tiene que listar los estilos).
- En el proyecto de Remotion: `npx remotion versions` (todo con la misma versión).
- Recomendado (una sola vez, ~3 GB): `python -c "from faster_whisper import WhisperModel; WhisperModel('large-v3', device='cpu', compute_type='int8'); print('modelo ok')"`.
  Al usuario decile "bajo el modelo de voz, tarda un rato la primera vez".

## 5. Dejar anotado
- En tu memoria: dónde quedó el proyecto de Remotion, qué Python usar, en qué disco van los proyectos
  (los renders llenan el disco con temporales) y que las entregas van al Escritorio, en una carpeta con
  el nombre de la marca.
- Al usuario, en 3 o 4 líneas y sin nombres técnicos: qué quedó listo, qué falta y si tiene que hacer algo.
