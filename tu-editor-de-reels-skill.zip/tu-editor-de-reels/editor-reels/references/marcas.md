# Fichas de marcas

Antes de editar una marca nueva, armá su ficha mirando **la web** (no el guion) y guardala acá. Las
condiciones comerciales cambian: volvé a mirar la web en cada jornada y anotá la fecha.

## Ficha de marca nueva (qué relevar de la web)
- Rubro y público; tono (cercano, lujo, urbano…).
- Colores: fondo, texto, botones, barra de anuncios, color del precio con transferencia.
- Tipografías: títulos, texto, botones (inspeccionar o comparar con Google Fonts).
- Logo (PNG transparente; si es blanco, placa de color detrás).
- Condiciones: % transferencia, cuotas, envío gratis desde, local.
- Productos del guion: nombre exacto, URL, precio de lista y con transferencia, variantes.
- Voz de la marca, si usa voz generada.
- Rarezas: datos contradictorios en la web, productos sin página, nombres parecidos.

## Ejemplo (marca ficticia)

### Tu Marca — tumarca.com (calzado de mujer)
- Zuecos (Brisa), sandalias (Alba, taco bajo).
- Web blanca y negra; textos en Poppins, títulos en Playfair Display; acento crema #F5E6C8; gris
  #6B7280; precio con transferencia en verde #2F8A2A; logo PNG negro.
- 25% OFF transferencia · 3 y 6 cuotas sin interés · envío gratis desde $150.000.
- El color "charol" de las Alba no tiene página propia: en el celular se muestra la página del modelo.

## Lecciones por rubro (de marcas reales)

- **Calzado:** planos de producto de al menos 1 s y en cámara lenta; los títulos van arriba cuando el
  producto está en el piso. Si un color no tiene página propia, mostrá la del modelo. Si el guion trae
  condiciones viejas (cuotas, envío), usá las de la web y avisá.
- **Ropa de mujer:** en planos enteros, títulos a la altura del torso (0.44–0.6), porque arriba está la
  cara. Texto blanco sobre remera blanca no se lee: sombra de color "dura" o texto de color con halo
  blanco. Las tomas con charla del equipo de fondo van siempre mudas.
- **Uniformes o indumentaria técnica:** si la tipografía de la web no está en Google Fonts, cargala como
  archivo. Si la web muestra dos montos distintos para el mismo dato, no lo uses. Si el reel nombra un
  precio que la web todavía no muestra, no lo pongas en pantalla.
- **Camisas y prendas con nombre de modelo:** verificá el nombre en la web; si no está confirmado,
  describí la prenda sin nombre. "Que no corte palabras": cortes solo en silencio real.
- **Básicos:** si en un audio se dice mal un dato (por ejemplo "5%" en vez de "15%"), cortá esa parte y
  poné el dato correcto en pantalla. Precios grandes en una serif con presencia.
- **Ropa urbana:** en lanzamientos, sin la palabra "oferta". Más lento cuando se ve el producto. Un
  video por crudo funciona muy bien.
- **Calzado con plataforma o de nicho:** subtítulos sin fondo ni contorno; variá la edición entre
  reels; no cortes la voz para estirarla; cuando se habla del producto, se ve el producto, no la cara.
- **Arte o lujo:** blanco y negro, grano, tipografía condensada en mayúscula, logo chico. Nunca
  descuentos ni urgencia falsa. Lo que más gustó: guion sobrador con un gag de interfaz falsa por frase.
  Nada de 3D ni cromados.
- **Marca personal:** estética de blog, grabaciones de pantalla nativas, subtítulos sin pastilla y sin
  "comentá X" si no lo pide.
